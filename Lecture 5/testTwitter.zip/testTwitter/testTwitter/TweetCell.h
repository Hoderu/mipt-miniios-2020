//
//  TweetCell.h
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Tweet.h"
@import UIKit;

typedef void (^ImageBlock)(UIImage* image);

@interface TweetCell : UITableViewCell

@property (weak, nonatomic) UIImage* image;

- (void)configureWithTweet:(Tweet*)tweet image:(UIImage*)image completion:(ImageBlock)completion;
+ (CGFloat)getCellHeight:(Tweet*)tweet width:(CGFloat)width height:(CGFloat)height;
@end

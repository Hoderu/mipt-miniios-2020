//
//  FMDBBase.h
//  testTwitter
//
//  Created by Андрей Решетников on 07.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^CachedTweetsBlock)(NSArray* tweets, NSError* error);
typedef void (^StoreTweetsBlock)(BOOL success, NSError* error);

@interface FMDBBase : NSObject

+ (instancetype)sharedInstance;

- (void)getCachedTweets:(CachedTweetsBlock)completionBlock;
- (void)writeTweetsToBase:(NSArray*)tweets completion:(StoreTweetsBlock)completionBlock;

@end

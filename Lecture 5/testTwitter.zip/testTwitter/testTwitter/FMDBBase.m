//
//  FMDBBase.m
//  testTwitter
//
//  Created by Андрей Решетников on 07.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "FMDBBase.h"
#import <FMDB/FMDB.h>
#import "User.h"
#import "Tweet.h"

@interface FMDBBase ()

@property (nonatomic, strong) FMDatabase* base;
@property (nonatomic, strong) FMDatabaseQueue* baseQueue;

@end

@implementation FMDBBase

+ (instancetype)sharedInstance
{
    static FMDBBase* store = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        store = [[self alloc] init];
    });
    
    return store;
}

#pragma mark - Methods

- (instancetype)init {
    if (self = [super init]) {
        NSString* baseName = [self baseName];
        self.base = [FMDatabase databaseWithPath:baseName];
        self.baseQueue = [FMDatabaseQueue databaseQueueWithPath:baseName];
        if (![self.base open]) {
            return nil;
        }
        [self create];
    }
    return self;
}

- (void)create {
    [self.baseQueue inDatabase:^(FMDatabase* db) {
        
        BOOL result = [db executeUpdate:@"CREATE TABLE IF NOT EXISTS user (idStr TEXT PRIMARY KEY, name TEXT, imageURL TEXT);"];
        if (!result) NSLog(@"CREATE TABLE user failed: %@", [db lastErrorMessage]);
        
        result = [db executeUpdate:@"CREATE TABLE IF NOT EXISTS tweet (idStr TEXT, text TEXT, user TEXT, FOREIGN KEY(user) REFERENCES user(idStr));"];
        if (!result) NSLog(@"CREATE TABLE tweet failed: %@", [db lastErrorMessage]);
    }];
}

- (NSString*)baseName {
    return [NSTemporaryDirectory() stringByAppendingPathComponent:@"myCachedTweets.db"];
}

- (void)getCachedTweets:(CachedTweetsBlock)completionBlock
{
    if (!completionBlock) {
        return;
    }
    [self.baseQueue inDatabase:^(FMDatabase* db) {
        FMResultSet* resultSet = [db executeQuery:@"SELECT t.idStr t_idStr, t.text t_text, t.user t_user, u.idStr u_idStr, u.name u_name, u.imageURL u_imageURL FROM tweet t JOIN user u ON t.user = u.idStr ORDER BY t.idStr DESC"];
        if (!resultSet) {
            completionBlock(nil, nil);
            return;
        }
        
        NSMutableArray* tweets = [NSMutableArray array];
        while ([resultSet next]) {
            User* user = [[User alloc] init];
            user.idStr = [resultSet stringForColumn:@"u_idStr"];
            user.name = [resultSet stringForColumn:@"u_name"];
            user.imageURL = [NSURL URLWithString:[resultSet stringForColumn:@"u_imageURL"]];
            
            Tweet* tweet = [[Tweet alloc] init];
            tweet.idStr = [resultSet stringForColumn:@"t_idStr"];
            tweet.text = [resultSet stringForColumn:@"t_text"];
            tweet.user = user;
            
            [tweets addObject:tweet];
        }
        
        [resultSet close];
        
        completionBlock(tweets, nil);
    }];
}

- (void)writeTweetsToBase:(NSArray*)tweets completion:(StoreTweetsBlock)completionBlock
{
    NSMutableSet* users = [NSMutableSet set];
    for (Tweet* tweet in tweets) {
        [users addObject:tweet.user];
    }
    
    [self.baseQueue inTransaction:^(FMDatabase* db, BOOL* rollback) {
        BOOL successFlag;

        successFlag = [db executeUpdate:@"DELETE FROM tweet"];
        if (!successFlag) goto cleanup;
        
        successFlag = [db executeUpdate:@"DELETE FROM user"];
        if (!successFlag) goto cleanup;
        
        for (User* user in users) {
            NSDictionary* userDictionary = @{ @"idStr" : user.idStr,
                                              @"name" : user.name ?: [NSNull null],
                                              @"imageURL" : user.imageURL ?: [NSNull null] };
            successFlag = [db executeUpdate:@"INSERT INTO user (idStr, name, imageURL) VALUES (:idStr, :name, :imageURL)"
                      withParameterDictionary:userDictionary];
            if (!successFlag) goto cleanup;
        }
        
        for (Tweet* tweet in tweets) {
            NSDictionary* tweetDictionary = @{ @"idStr" : tweet.idStr,
                                               @"text" : tweet.text ?: [NSNull null],
                                               @"user" : tweet.user.idStr ?: [NSNull null] };
            successFlag = [db executeUpdate:@"INSERT INTO tweet (idStr, text, user) VALUES (:idStr, :text, :user)"
                      withParameterDictionary:tweetDictionary];
            if (!successFlag) goto cleanup;
        }
        
    cleanup:
        if (!successFlag) {
            *rollback = YES;
        }
        if (completionBlock) {
            completionBlock(successFlag, nil);
        }
    }];
}

@end

//
//  Tweet.h
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import <Foundation/Foundation.h>

@class User;

@interface Tweet : NSObject <NSCopying>

@property (nonatomic, copy) NSString* idStr;
@property (nonatomic, copy) NSString* text;
@property (nonatomic, copy) User* user;

- (instancetype)initWithJSON:(NSDictionary*)dictionary;

@end

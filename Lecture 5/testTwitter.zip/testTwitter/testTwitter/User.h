//
//  User.h
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject <NSCopying>

@property (nonatomic, copy) NSString* idStr;
@property (nonatomic, copy) NSString* name;
@property (nonatomic, copy) NSURL* imageURL;

- (instancetype)initWithJSON:(NSDictionary*)dictionary;

@end

//
//  SettingsTableViewController.m
//  testTwitter
//
//  Created by Андрей Решетников on 06.09.16.
//  Copyright © 2016 Андрей Решетников. All rights reserved.
//

#import "SettingsTableViewController.h"

@interface SettingsTableViewController ()

@property (weak, nonatomic) IBOutlet UISwitch *showAvatarsSwitch;
@property (nonatomic, strong) NSUserDefaults* userDefaults;

@end

@implementation SettingsTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.userDefaults = [NSUserDefaults standardUserDefaults];
    BOOL isOn = [self.userDefaults boolForKey:@"TwitterSaveAvatarsKey"];
    self.showAvatarsSwitch.on = isOn;
}

- (IBAction)switchTouched:(id)sender
{
    BOOL isOn = [self.showAvatarsSwitch isOn];
    [self.userDefaults setBool:isOn forKey:@"TwitterSaveAvatarsKey"];
    [self.userDefaults synchronize];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
